

 </div>
	 <div id="gbvis_footer">
	  <div class="gbvis_footer-left">
	  <a href="#" align="left" style="font-family:Verdana, Geneva,  sans-serif; font-size:15px; color:white; text-decoration:none;padding-right:2px;padding-left:2px;">Terms And conditions</a>
	</div> 
	<div class="gbvis_footer-center">
	  <a href="#" align="left" style="font-family:Verdana, Geneva, sans-serif; font-size:15px; color:white; text-decoration:none;padding-right:2px;padding-left:2px;">Support</a>
	</div> 
	<div class="gbvis_footer-right">
	  <p style="font-family:Verdana, Geneva, sans-serif; font-size:15px; color:white; text-decoration:none;padding-right:2px;padding-left:2px;"> All Rights Reserved &copy2015 </p>
	</div> 
	</div> 
    </div>
</center>
</body>
</html>
