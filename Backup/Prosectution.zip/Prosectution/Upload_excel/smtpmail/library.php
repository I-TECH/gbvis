<?php
error_reporting(0);
define("SMTP_HOST", "mail.ardech.co.ke"); //Hostname of the mail server
define("SMTP_PORT", "587"); //Port of the SMTP like to be 25, 80, 465 or 587
define("SMTP_UNAME", "info@ardech.co.ke"); //Username for SMTP authentication any valid email created in your domain
define("SMTP_PWORD", "123.qwe"); //Password for SMTP authentication
// you can get your SMTP host here http://www.asif18.com/6/php/list-of-smtp-and-pop3-severs,-hosts,-ports-email-servers/
?>